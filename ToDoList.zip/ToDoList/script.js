let items = [];
var indexid;
$(".btn").on("click", function (event) {
    event.preventDefault();
    var btnvalue = $(this).text();
    var inputvalue = $(".input-item").val();
    if(inputvalue==""){
   alert('Please enter value');
   return;
}
    if (btnvalue.toLowerCase() == "store") {
        addItemsToList(inputvalue);
    } else {
        updateItemsInList();
    }
});
function addItemsToList(value) {
    items.push(value);
    //$(".item-list").empty();
    readArrData(items);
    //$(".input-item").val("");
}

$(".item-list").on("click",".li-item",function (event) {
    event.preventDefault();
    var value = $(this).text();
    indexid = items.indexOf(value);
    $(".input-item").val(value);
    $(".btn").text("update");
});
$(document).on("click", ".remove", function () {
        var currentIndex = items.indexOf($(this).parent("li").text());
        $(this).parent("li").remove();
        items.splice(currentIndex, 1);
        // $(".btn").text("Store");
      });
function updateItemsInList() {
    var value = $(".input-item").val();
    items[indexid] = value;
    //$(".item-list").empty();
    readArrData(items);
    $(".btn").text("Store");
    //$(".input-item").val("");
}
function readArrData(items) {
    $(".item-list").empty();
    for (let i = 0; i < items.length; i++) {
    $(".item-list").append(`<li class=""><span class="li-item">${items[i]}</span> <span class="remove"><i class="fa-solid fa-trash"></i></span></li>`);
    }
    $(".input-item").val("");
}